# CivicChamp India: Technical Design Document

**Team:** Team Bijli | **Registration ID:** HSC\|KA\|00051 | **Hackathon:** Hack for Social Cause, VBYLD 2027 | **Theme:** Governance & Civic Technology

> This document describes a **front-end student prototype**. Anything labelled "proposed" or "future" is **not implemented**.

## 1. Introduction

**Purpose.** CivicChamp India is a browser-based prototype that makes civic learning and action engaging through quizzes, missions, XP, levels and badges.

**Problem addressed.** Littering, poor waste segregation, traffic indiscipline, water wastage and damage to public property are everyday civic concerns. Young people have few engaging ways to learn and practise civic habits.

**Target users.** School and college students, and community members who want a simple civic-learning tool.

**Design goals.**
- Mobile-first, responsive and easy to use.
- Runs from a single front-end project with no backend and no install.
- Privacy-friendly: no login, and photos and locations are not uploaded.
- Honest about limits: sample data is labelled, and nothing is claimed as verified or officially submitted.

## 2. Functional scope

The interface has six main areas.

| Area | Summary |
|---|---|
| Home / Dashboard | XP, level, missions completed, progress indicators and a daily civic challenge |
| Learn | Civic-awareness quiz with answers and explanations |
| Missions | Civic missions with instructions, one-time XP rewards and optional evidence |
| Rewards | Six achievement badges and a sample-user leaderboard |
| Impact | Charts and sample locality civic scores, labelled as illustrative demo data |
| Report / Complaints | Form to record civic issues, local reference IDs, a personal list with filters, and a sample community overview |

## 3. Current system architecture

| Layer | Role |
|---|---|
| HTML | Page structure and the content of each section |
| CSS | Styling, colour theme and responsive layout |
| JavaScript | Navigation, quiz and mission logic, XP and badge calculation, form validation, rendering |
| Browser `localStorage` | Local persistence of supported prototype data on the user's device |
| Camera input (optional) | Photo capture or selection, only after the user taps a button and permits access, where supported |
| Geolocation (optional) | Coordinates, only after the user taps a button and permits access, where supported |

```mermaid
flowchart TB
    User["Student or resident"]
    subgraph Browser["User's web browser - all processing and storage happen here"]
        HTML["HTML - page structure"]
        CSS["CSS - styling and responsive layout"]
        JS["JavaScript - application logic"]
        LS[("Browser localStorage")]
        CAM["Camera input - optional, permission required"]
        GEO["Geolocation - optional, permission required"]
    end
    User --> HTML
    HTML --> CSS
    HTML --> JS
    JS <--> LS
    JS --> CAM
    JS --> GEO
```

There is no server, API or database in the current architecture.

## 4. User workflow

```mermaid
flowchart TD
    A(["Open application"]) --> B["Home dashboard"]
    B --> C{"Choose an activity"}
    C -->|Learn| D["Take quiz and read explanations"]
    C -->|Missions| E["Complete a civic mission"]
    D --> F["Earn XP, level up, unlock badges"]
    E --> F
    F --> G{"Next step"}
    G -->|Impact| H["View sample impact charts and locality scores"]
    G -->|Report| I["Fill in civic issue form"]
    I --> J["Local demo record created with reference ID"]
    J --> K["Stored in this browser only - not sent to any authority"]
    H --> B
    K --> B
```

## 5. Component descriptions

Behaviour below reflects the prototype as designed; confirm details against `index.html` before final submission.

### Home / Dashboard
- **Purpose:** summarise progress.
- **Inputs:** a button to mark the daily challenge done; navigation buttons.
- **Outputs:** XP, level, missions completed, progress bars.
- **Behaviour:** the daily challenge can be completed once per day.

### Learn
- **Purpose:** teach civic basics.
- **Inputs:** one answer choice per question.
- **Outputs:** correct or incorrect feedback, an explanation, a score and a review.
- **Behaviour:** XP for a question is awarded the first time it is answered correctly. The quiz can be retaken without repeating XP.

### Missions
- **Purpose:** encourage real-world civic action.
- **Inputs:** completion button; optional photo, location and locality text.
- **Outputs:** XP, completed state, an "Evidence submitted — pending verification" label.
- **Behaviour:** each mission rewards XP once. Evidence is not independently verified.

### Rewards
- **Purpose:** recognise progress.
- **Outputs:** XP, level, six badges (locked or unlocked) and a leaderboard in which only "You" is the real user and all other names and scores are sample data.

### Impact
- **Purpose:** show how participation could be visualised.
- **Outputs:** the user's own activity chart, plus sample locality scores and sample cleanup figures labelled as demo data.
- **Behaviour:** the page explains how verified participation could help in a full system. No verification exists in this prototype.

### Report / Complaints
- **Inputs:** title, category, description, locality (required), urgency, optional photo and location.
- **Outputs:** a local reference ID, a saved record, a personal list with category and status filters, a detail view, and a community overview built from sample data.
- **Behaviour:** records are labelled "Submitted — demo only; not sent to authorities". Photos and precise coordinates are not shown in public listings.

## 6. Data flow

1. The user interacts with the page (taps, types, selects).
2. JavaScript validates input and updates in-memory state.
3. Supported data is written to `localStorage`.
4. On page load, saved data is read back and the interface is re-rendered.
5. Photos are held only as temporary in-browser previews and are not written to `localStorage`.

```mermaid
flowchart LR
    U["User action"] --> J["JavaScript validates and updates state"]
    J --> R["Interface re-renders"]
    J --> S[("localStorage - supported data")]
    S -->|"read on page load"| J
    J -.->|"optional, permission required"| P["Camera preview - temporary, in memory"]
    J -.->|"optional, permission required"| L["Coordinates - rounded when saved"]
```

## 7. Data design

These are **conceptual entities**. There are **no database tables** and no central database in the current prototype. Exact field names should be checked against the source code.

| Concept | Conceptual contents | Persisted in `localStorage`? |
|---|---|---|
| User progress | XP total; level derived from XP | Yes (XP); level is calculated |
| Quiz interactions | Chosen answers, which questions have already earned XP, completion state, current question | Yes |
| Mission completion | Completed missions, time, whether a photo was attached, optional locality text, coarse coordinates | Yes |
| XP and badges | Unlocked badge flags; daily-challenge date and count | Yes |
| Illustrative locality scores | Sample locality names and scores, sample leaderboard, sample cleanup count | No, built into the page as sample data |
| Civic issue reports | Reference ID, title, category, description, locality, urgency, date, status, photo-attached flag, coarse coordinates; a counter for reference numbers | Yes |
| Photos | Image files | No, temporary preview only |

## 8. Security and privacy

- **Local storage limits:** data is unencrypted, readable by anyone with access to the browser profile, specific to one browser and device, limited in size, and lost if browser data is cleared.
- **Permissions:** the camera and location are requested only after the user taps a button. Browsers generally need HTTPS or `localhost`. Denial is handled by letting the user type a locality and continue without a photo.
- **Sensitive information:** the report form warns users not to enter personal details. The form also checks for obvious phone, ID and email patterns, but this is not a guarantee.
- **No centralised authentication:** there are no accounts, so identity cannot be verified and one browser user cannot be told apart from another.
- **Not a production service:** the prototype has no server-side validation, access control, audit trail, data retention policy or integration with any authority. It must not be used for real emergencies or real complaints.

## 9. Current limitations

- No backend, API or central database.
- No server-backed authentication.
- Complaints are not forwarded to any authority.
- Evidence is not verified by anyone.
- No government or civic-body integration.
- No SMS or IVR notifications.
- No verified real-world impact measurement. Impact, leaderboard, locality and cleanup figures are samples.
- Progress is not shared across devices or browsers.
- Photos are not retained after a refresh.
- Features depend on browser support and permissions.

## 10. Proposed future architecture

**PROPOSED FUTURE ARCHITECTURE — NOT IMPLEMENTED**

```mermaid
flowchart TB
    subgraph Future["PROPOSED FUTURE ARCHITECTURE - NOT IMPLEMENTED"]
        C["Proposed: Web and mobile client"]
        A["Proposed: Authentication and authorization"]
        API["Proposed: Backend API"]
        DB[("Proposed: Central database")]
        V["Proposed: Evidence verification workflow"]
        I["Proposed: Approved civic authority integration"]
        AN["Proposed: Analytics dashboard"]
        C --> A
        A --> API
        C --> API
        API --> DB
        API --> V
        V --> I
        DB --> AN
    end
```

## 11. Future enhancements

All items are proposed only.

- **Backend and centralised storage** for accounts, progress and reports.
- **Verified civic participation** through teacher, volunteer or authority review, with clear privacy rules.
- **Regional-language support** for Kannada and other Indian languages.
- **Accessibility improvements** such as screen-reader testing and keyboard-navigation review.
- **Analytics** based on verified data, shown only with clear methodology.
- **Partnerships** with schools, colleges, NGOs and local civic bodies, only through approved channels.
- **Low-connectivity access** through SMS or IVR.

## 12. Technical assumptions

- The app is a single front-end project using HTML, CSS, JavaScript and `localStorage`.
- Users run a modern browser; camera and location work only with support, permission and a secure origin (HTTPS or `localhost`).

**Verify against the actual source code before submission:**
- Exact `localStorage` key names and stored fields.
- The number and wording of quiz questions, missions and badges.
- XP values, level thresholds and badge unlock rules.
- Reference ID format and counter behaviour.
- Which missions offer camera or location options.
- That no `fetch`, XHR or other network calls exist.
- That `index.html` has not changed since this document was written.
