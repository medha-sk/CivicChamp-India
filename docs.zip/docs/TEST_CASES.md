# CivicChamp India: Manual Test Cases

**Team:** Team Bijli | **Registration ID:** HSC\|KA\|00051

## Testing summary

These are **proposed manual test cases**. None has been executed. Every Actual Result and Status is **Not Run** until you perform the test. Do not mark a case as Passed without running it. Where behaviour depends on the exact implementation, the expected result says **Verify against current implementation**.

Suggested environments: desktop Chrome or Edge, and an Android or iOS phone. Test camera and location over HTTPS or `http://localhost:8000`.

| Test Case ID | Feature | Preconditions | Test Steps | Expected Result | Actual Result | Status |
|---|---|---|---|---|---|---|
| TC-01 | Application loading | Modern browser; `index.html` available | 1. Open `index.html` (or `http://localhost:8000`).<br>2. Observe the first screen. | Home dashboard loads with no errors. XP, level and navigation are visible. | Not Run | Not Run |
| TC-02 | Navigation | App loaded | 1. Select each navigation item in turn.<br>2. Return to Home. | Each item shows its own section. The active item is highlighted. No section is blank. | Not Run | Not Run |
| TC-03 | Quiz interaction | On the Learn section | 1. Select an answer.<br>2. Read the feedback.<br>3. Continue to the end. | Feedback and an explanation appear after each answer. A final score is shown. Verify against current implementation. | Not Run | Not Run |
| TC-04 | Mission display | On the Missions section | 1. Review each mission card. | Each mission shows a title, description, instructions, XP reward and a completion button. | Not Run | Not Run |
| TC-05 | Mission completion and XP | Fresh state; no missions completed | 1. Complete one mission.<br>2. Check Home and Rewards. | XP increases by the mission's reward. Mission count and progress update. A success message appears. | Not Run | Not Run |
| TC-06 | Duplicate reward prevention | One mission already completed | 1. Try to complete the same mission again. | The button is disabled or refused. XP does not increase a second time. | Not Run | Not Run |
| TC-07 | Badge display | On the Rewards section | 1. View all badges.<br>2. Complete an activity that meets a badge condition. | Six badges are listed as locked or unlocked. A badge unlocks when its condition is met. Verify against current implementation. | Not Run | Not Run |
| TC-08 | Impact chart and demo-data labelling | On the Impact section | 1. View charts and locality scores.<br>2. Look for labels. | Charts render. Sample locality scores, sample cleanup figures and sample data are clearly labelled as demo data. | Not Run | Not Run |
| TC-09 | Report form validation | On the Report section | 1. Submit the empty form.<br>2. Fill only some required fields and submit. | Missing required fields (title, category, description, locality) show clear errors. No record is created. | Not Run | Not Run |
| TC-10 | Local complaint record | Required fields filled | 1. Submit the form.<br>2. Open My Complaints. | A reference ID is shown. The record appears with the label that it is demo only and not sent to authorities. | Not Run | Not Run |
| TC-11 | Persistence after refresh | Progress made and one complaint saved | 1. Refresh the page.<br>2. Check XP, missions, badges and complaints. | Saved progress and complaints remain. Photo previews may not persist. | Not Run | Not Run |
| TC-12 | Camera access | Secure origin; device with a camera | 1. Tap the photo button on a mission or the report form.<br>2. Grant permission or capture a photo.<br>3. Retake the photo. | A preview is shown and can be retaken or removed. On laptops a file picker may open instead. Verify against current implementation. | Not Run | Not Run |
| TC-13 | Camera denial fallback | Camera blocked, unavailable or no photo chosen | 1. Deny or cancel the camera.<br>2. Complete a mission or submit a report without a photo. | A friendly message is shown, or nothing breaks. The user can continue without a photo. | Not Run | Not Run |
| TC-14 | Location denial | Secure origin | 1. Tap Use My Location.<br>2. Deny permission.<br>3. Type a locality manually. | A clear message appears. Manual locality entry works. The mission or complaint can still be saved. | Not Run | Not Run |
| TC-15 | Browser storage reset | Some saved progress exists | 1. Use Reset demo and confirm.<br>2. Refresh. | XP, missions, quiz results, badges and complaints are cleared and the app returns to its starting state. | Not Run | Not Run |
| TC-16 | Responsive layout | App loaded | 1. View at phone width and desktop width.<br>2. Check navigation, forms and charts. | No horizontal scrolling. Buttons are usable by touch. Text is readable. | Not Run | Not Run |
| TC-17 | Public live-demo access | Live demo URL published | 1. Open `YOUR_LIVE_DEMO_URL` on another device or network.<br>2. Repeat TC-01 and TC-02. | The page loads publicly with no login. Replace the placeholder with the real URL first. | Not Run | Not Run |

## Execution record

| Tester | Date | Browser and device | Notes |
|---|---|---|---|
| | | | |
